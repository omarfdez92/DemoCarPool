package com.omarparra.democarpool

/**
 * @author Ing. Omar Parra
 * @date 11/7/19
 */

class Persons(val name: String, val tcsLocation: String, val image: String){
    override fun toString(): String {
        return name
    }
}